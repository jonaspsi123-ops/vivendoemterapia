/**
 * Stripe Products and Prices Configuration
 * 
 * These are the product IDs and price IDs for the subscription plans.
 * In test mode, you can use the test product IDs below.
 * In production, you'll need to create these in your Stripe dashboard.
 */

export const STRIPE_PRODUCTS = {
  MONTHLY: {
    priceId: process.env.STRIPE_MONTHLY_PRICE_ID || 'price_test_monthly',
    name: 'Plano Mensal',
    amount: 4900, // R$ 49.00 in cents
    interval: 'month',
    currency: 'brl',
  },
  ANNUAL: {
    priceId: process.env.STRIPE_ANNUAL_PRICE_ID || 'price_test_annual',
    name: 'Plano Anual',
    amount: 28000, // R$ 280.00 in cents
    interval: 'year',
    currency: 'brl',
  },
};

export type SubscriptionPlan = keyof typeof STRIPE_PRODUCTS;

export function getProductInfo(plan: SubscriptionPlan) {
  return STRIPE_PRODUCTS[plan];
}

export function getPriceId(plan: SubscriptionPlan): string {
  return STRIPE_PRODUCTS[plan].priceId;
}
