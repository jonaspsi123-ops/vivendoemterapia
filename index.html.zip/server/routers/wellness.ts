import { z } from 'zod';
import { protectedProcedure, publicProcedure, router } from '../_core/trpc';
import { getDb, getTodaysTip, getAllExercises } from '../db';
import { dailyTips, exercises, userExercises, userTipHistory } from '../../drizzle/schema';
import { eq, desc } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';
import { invokeLLM } from '../_core/llm';

export const wellnessRouter = router({
  /**
   * Get today's wellness tip
   */
  getTodaysTip: protectedProcedure.query(async ({ ctx }) => {
    // Check if user has active subscription
    if (ctx.user.subscriptionStatus !== 'active') {
      throw new TRPCError({
        code: 'FORBIDDEN',
        message: 'This feature requires an active subscription',
      });
    }

    const db = await getDb();
    if (!db) {
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Database connection failed',
      });
    }

    let tip = await getTodaysTip();

    // If no tip exists for today, generate one
    if (!tip) {
      try {
        const response = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'You are a compassionate therapist and wellness expert. Generate a short, inspiring daily tip for emotional well-being. Respond in Portuguese.',
            },
            {
              role: 'user',
              content: 'Generate a daily wellness tip about managing emotions and feelings. Keep it concise (2-3 sentences) and actionable.',
            },
          ],
        });

        const content = response.choices[0]?.message.content as string;
        if (!content) {
          throw new Error('No content generated');
        }

        // Extract category from content (simple heuristic)
        const categories = ['emotion', 'stress', 'anxiety', 'sleep', 'focus', 'relationships', 'general'];
        let category: typeof categories[number] = 'general';
        
        const contentLower = content.toLowerCase();
        for (const cat of categories) {
          if (contentLower.includes(cat)) {
            category = cat;
            break;
          }
        }

        // Save tip to database
        await db.insert(dailyTips).values({
          title: 'Dica do Dia',
          content,
          category: category as any,
          generatedAt: new Date(),
          createdAt: new Date(),
        });

        tip = await getTodaysTip();
      } catch (error) {
        console.error('[Wellness] Error generating tip:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to generate wellness tip',
        });
      }
    }

    // Record that user viewed this tip
    if (tip) {
      try {
        await db.insert(userTipHistory).values({
          userId: ctx.user.id,
          tipId: tip.id,
          viewedAt: new Date(),
          createdAt: new Date(),
        });
      } catch (error) {
        console.warn('[Wellness] Error recording tip view:', error);
      }
    }

    return tip;
  }),

  /**
   * Get all therapeutic exercises
   */
  getExercises: protectedProcedure
    .input(z.object({
      type: z.enum(['breathing', 'mindfulness', 'journaling', 'meditation', 'grounding', 'visualization', 'movement']).optional(),
      difficulty: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      let query = db.select().from(exercises) as any;

      if (input?.type) {
        query = query.where(eq(exercises.type, input.type as any));
      }

      if (input?.difficulty) {
        query = query.where(eq(exercises.difficulty, input.difficulty as any));
      }

      return await query;
    }),

  /**
   * Get a specific exercise by ID
   */
  getExercise: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      const result = await db.select().from(exercises).where(eq(exercises.id, input.id)).limit(1);
      if (result.length === 0) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Exercise not found',
        });
      }

      return result[0];
    }),

  /**
   * Mark exercise as completed
   */
  completeExercise: protectedProcedure
    .input(z.object({
      exerciseId: z.number(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        const result = await db.insert(userExercises).values({
          userId: ctx.user.id,
          exerciseId: input.exerciseId,
          completedAt: new Date(),
          notes: input.notes || null,
          createdAt: new Date(),
        });

        return { success: true };
      } catch (error) {
        console.error('[Wellness] Error completing exercise:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to record exercise completion',
        });
      }
    }),

  /**
   * Get user's exercise history
   */
  getExerciseHistory: protectedProcedure
    .input(z.object({
      limit: z.number().default(10),
      offset: z.number().default(0),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      const history = await db
        .select()
        .from(userExercises)
        .where(eq(userExercises.userId, ctx.user.id))
        .orderBy(desc(userExercises.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      return history;
    }),

  /**
   * Get user's tip history
   */
  getTipHistory: protectedProcedure
    .input(z.object({
      limit: z.number().default(10),
      offset: z.number().default(0),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      const history = await db
        .select()
        .from(userTipHistory)
        .where(eq(userTipHistory.userId, ctx.user.id))
        .orderBy(desc(userTipHistory.viewedAt))
        .limit(input.limit)
        .offset(input.offset);

      return history;
    }),
});
