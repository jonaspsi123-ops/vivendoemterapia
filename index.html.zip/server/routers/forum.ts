import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { forumCategories, forumTopics, forumReplies, forumReplyVotes, forumUserReputation } from '../../drizzle/schema';
import { eq, desc, and, like } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

// Offensive words filter for moderation
const OFFENSIVE_WORDS = [
  'spam', 'hate', 'violence', 'suicide', 'self-harm',
  // Add more as needed
];

function filterContent(content: string): string {
  let filtered = content;
  OFFENSIVE_WORDS.forEach(word => {
    const regex = new RegExp(word, 'gi');
    filtered = filtered.replace(regex, '*'.repeat(word.length));
  });
  return filtered;
}

function generateAnonymousNumber(userId: number): number {
  // Generate consistent anonymous number based on userId
  return Math.abs(userId * 7919) % 9999 + 1;
}

export const forumRouter = router({
  /**
   * Get all forum categories
   */
  getCategories: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) {
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Database connection failed',
      });
    }

    return await db.select().from(forumCategories);
  }),

  /**
   * Get topics in a category with pagination
   */
  getTopics: protectedProcedure
    .input(z.object({
      categoryId: z.number().optional(),
      limit: z.number().default(20),
      offset: z.number().default(0),
      search: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      let query = db.select().from(forumTopics) as any;

      if (input.categoryId) {
        query = query.where(eq(forumTopics.categoryId, input.categoryId));
      }

      // Simple search in title
      if (input.search) {
        // Note: This is a simple search. For production, consider full-text search
        query = query.where(like(forumTopics.title, `%${input.search}%`));
      }

      const topics = await query
        .orderBy(desc(forumTopics.isPinned), desc(forumTopics.createdAt))
        .limit(input.limit)
        .offset(input.offset);

      return topics;
    }),

  /**
   * Get topic details with replies
   */
  getTopic: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      const topic = await db.select().from(forumTopics).where(eq(forumTopics.id, input.id)).limit(1);
      if (topic.length === 0) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Topic not found',
        });
      }

      // Increment view count
      await db.update(forumTopics)
        .set({ viewCount: topic[0].viewCount + 1 })
        .where(eq(forumTopics.id, input.id));

      // Get replies
      const replies = await db.select().from(forumReplies)
        .where(eq(forumReplies.topicId, input.id))
        .orderBy(desc(forumReplies.helpfulCount), desc(forumReplies.createdAt));

      return {
        topic: topic[0],
        replies,
      };
    }),

  /**
   * Create a new forum topic
   */
  createTopic: protectedProcedure
    .input(z.object({
      categoryId: z.number(),
      title: z.string().min(5).max(255),
      content: z.string().min(10).max(5000),
    }))
    .mutation(async ({ input, ctx }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        const anonymousNumber = generateAnonymousNumber(ctx.user.id);
        const filteredContent = filterContent(input.content);

        await db.insert(forumTopics).values({
          userId: ctx.user.id,
          categoryId: input.categoryId,
          title: input.title,
          content: filteredContent,
          anonymousNumber,
          viewCount: 0,
          replyCount: 0,
          isPinned: false,
          isClosed: false,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        return { success: true };
      } catch (error) {
        console.error('[Forum] Error creating topic:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create topic',
        });
      }
    }),

  /**
   * Reply to a forum topic
   */
  createReply: protectedProcedure
    .input(z.object({
      topicId: z.number(),
      content: z.string().min(5).max(5000),
    }))
    .mutation(async ({ input, ctx }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        // Check if topic exists
        const topic = await db.select().from(forumTopics).where(eq(forumTopics.id, input.topicId)).limit(1);
        if (topic.length === 0) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Topic not found',
          });
        }

        if (topic[0].isClosed) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'This topic is closed',
          });
        }

        const anonymousNumber = generateAnonymousNumber(ctx.user.id);
        const filteredContent = filterContent(input.content);

        await db.insert(forumReplies).values({
          topicId: input.topicId,
          userId: ctx.user.id,
          content: filteredContent,
          anonymousNumber,
          helpfulCount: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        // Update topic reply count
        await db.update(forumTopics)
          .set({ replyCount: topic[0].replyCount + 1 })
          .where(eq(forumTopics.id, input.topicId));

        return { success: true };
      } catch (error) {
        console.error('[Forum] Error creating reply:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create reply',
        });
      }
    }),

  /**
   * Mark a reply as helpful
   */
  markReplyHelpful: protectedProcedure
    .input(z.object({
      replyId: z.number(),
      isHelpful: z.boolean(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        // Check if user already voted
        const existingVote = await db.select().from(forumReplyVotes)
          .where(and(
            eq(forumReplyVotes.replyId, input.replyId),
            eq(forumReplyVotes.userId, ctx.user.id)
          ))
          .limit(1);

        if (existingVote.length > 0) {
          // Update existing vote
          await db.update(forumReplyVotes)
            .set({ isHelpful: input.isHelpful })
            .where(and(
              eq(forumReplyVotes.replyId, input.replyId),
              eq(forumReplyVotes.userId, ctx.user.id)
            ));
        } else {
          // Create new vote
          await db.insert(forumReplyVotes).values({
            replyId: input.replyId,
            userId: ctx.user.id,
            isHelpful: input.isHelpful,
            createdAt: new Date(),
          });
        }

        // Update reply helpful count
        const reply = await db.select().from(forumReplies).where(eq(forumReplies.id, input.replyId)).limit(1);
        if (reply.length > 0) {
          const newCount = input.isHelpful ? reply[0].helpfulCount + 1 : Math.max(0, reply[0].helpfulCount - 1);
          await db.update(forumReplies)
            .set({ helpfulCount: newCount })
            .where(eq(forumReplies.id, input.replyId));

          // Update user reputation
          const userRep = await db.select().from(forumUserReputation)
            .where(eq(forumUserReputation.userId, reply[0].userId))
            .limit(1);

          if (userRep.length > 0) {
            const newPoints = input.isHelpful ? userRep[0].points + 1 : Math.max(0, userRep[0].points - 1);
            const newHelpful = input.isHelpful ? userRep[0].helpfulReplies + 1 : Math.max(0, userRep[0].helpfulReplies - 1);
            await db.update(forumUserReputation)
              .set({ points: newPoints, helpfulReplies: newHelpful })
              .where(eq(forumUserReputation.userId, reply[0].userId));
          } else {
            // Create new reputation entry
            await db.insert(forumUserReputation).values({
              userId: reply[0].userId,
              points: input.isHelpful ? 1 : 0,
              helpfulReplies: input.isHelpful ? 1 : 0,
              createdAt: new Date(),
              updatedAt: new Date(),
            });
          }
        }

        return { success: true };
      } catch (error) {
        console.error('[Forum] Error marking reply helpful:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to mark reply helpful',
        });
      }
    }),

  /**
   * Get user's forum reputation
   */
  getUserReputation: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Database connection failed',
      });
    }

    const reputation = await db.select().from(forumUserReputation)
      .where(eq(forumUserReputation.userId, ctx.user.id))
      .limit(1);

    if (reputation.length === 0) {
      return {
        points: 0,
        helpfulReplies: 0,
      };
    }

    return reputation[0];
  }),
});
