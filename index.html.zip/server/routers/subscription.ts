import { z } from 'zod';
import Stripe from 'stripe';
import { protectedProcedure, router } from '../_core/trpc';
import { getDb, getUserById } from '../db';
import { STRIPE_PRODUCTS, SubscriptionPlan } from '../products';
import { TRPCError } from '@trpc/server';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2026-04-22.dahlia',
});

export const subscriptionRouter = router({
  /**
   * Get current user's subscription status
   */
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const user = await getUserById(ctx.user.id);
    if (!user) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    return {
      status: user.subscriptionStatus,
      plan: user.subscriptionPlan,
      startDate: user.subscriptionStartDate,
      endDate: user.subscriptionEndDate,
      stripeCustomerId: user.stripeCustomerId,
    };
  }),

  /**
   * Create a Stripe checkout session for subscription
   */
  createCheckoutSession: protectedProcedure
    .input(z.object({
      plan: z.enum(['MONTHLY', 'ANNUAL']),
      returnUrl: z.string().url(),
    }))
    .mutation(async ({ ctx, input }) => {
      const user = await getUserById(ctx.user.id);
      if (!user) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
      }

      const productInfo = STRIPE_PRODUCTS[input.plan as SubscriptionPlan];
      if (!productInfo) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: 'Invalid plan' });
      }

      try {
        // Get or create Stripe customer
        let customerId = user.stripeCustomerId;
        if (!customerId) {
          const customer = await stripe.customers.create({
            email: user.email,
            name: user.name || undefined,
            metadata: {
              userId: user.id.toString(),
            },
          });
          customerId = customer.id;

          // Update user with Stripe customer ID
          const db = await getDb();
          if (db) {
            await db.update(require('../drizzle/schema').users)
              .set({ stripeCustomerId: customerId })
              .where(require('drizzle-orm').eq(require('../drizzle/schema').users.id, user.id));
          }
        }

        // Create checkout session
        const session = await stripe.checkout.sessions.create({
          customer: customerId,
          payment_method_types: ['card'],
          line_items: [
            {
              price: productInfo.priceId,
              quantity: 1,
            },
          ],
          mode: 'subscription',
          success_url: `${input.returnUrl}?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: input.returnUrl,
          metadata: {
            userId: user.id.toString(),
            plan: input.plan,
          },
          allow_promotion_codes: true,
        });

        if (!session.url) {
          throw new TRPCError({ 
            code: 'INTERNAL_SERVER_ERROR', 
            message: 'Failed to create checkout session' 
          });
        }

        return {
          sessionId: session.id,
          url: session.url,
        };
      } catch (error) {
        console.error('[Stripe] Error creating checkout session:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create checkout session',
        });
      }
    }),

  /**
   * Get checkout session details
   */
  getCheckoutSession: protectedProcedure
    .input(z.object({
      sessionId: z.string(),
    }))
    .query(async ({ input }) => {
      try {
        const session = await stripe.checkout.sessions.retrieve(input.sessionId);
        return {
          id: session.id,
          status: session.payment_status,
          subscriptionId: session.subscription as string | null,
          customerId: session.customer as string | null,
        };
      } catch (error) {
        console.error('[Stripe] Error retrieving checkout session:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to retrieve checkout session',
        });
      }
    }),

  /**
   * Cancel subscription
   */
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    const user = await getUserById(ctx.user.id);
    if (!user) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
    }

    if (!user.stripeSubscriptionId) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: 'No active subscription',
      });
    }

    try {
      await stripe.subscriptions.cancel(user.stripeSubscriptionId);

      // Update user subscription status
      const db = await getDb();
      if (db) {
        const { users } = require('../drizzle/schema');
        const { eq } = require('drizzle-orm');
        await db.update(users)
          .set({ 
            subscriptionStatus: 'cancelled',
            subscriptionEndDate: new Date(),
          })
          .where(eq(users.id, user.id));
      }

      return { success: true };
    } catch (error) {
      console.error('[Stripe] Error cancelling subscription:', error);
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Failed to cancel subscription',
      });
    }
  }),

  /**
   * Get subscription portal link
   */
  getPortalLink: protectedProcedure
    .input(z.object({
      returnUrl: z.string().url(),
    }))
    .query(async ({ ctx, input }) => {
      const user = await getUserById(ctx.user.id);
      if (!user) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'User not found' });
      }

      if (!user.stripeCustomerId) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'No Stripe customer found',
        });
      }

      try {
        const session = await stripe.billingPortal.sessions.create({
          customer: user.stripeCustomerId,
          return_url: input.returnUrl,
        });

        return { url: session.url };
      } catch (error) {
        console.error('[Stripe] Error creating portal session:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create billing portal link',
        });
      }
    }),
});
