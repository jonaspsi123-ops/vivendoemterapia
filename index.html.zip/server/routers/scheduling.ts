import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { therapySessions, therapistAvailability, users } from '../../drizzle/schema';
import { eq, desc, and, gte } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

export const schedulingRouter = router({
  /**
   * Get available time slots for a therapist
   */
  getAvailableSlots: protectedProcedure
    .input(z.object({
      therapistId: z.number(),
      date: z.string(), // YYYY-MM-DD format
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        const date = new Date(input.date);
        const dayOfWeek = date.getDay();

        // Get therapist availability for this day
        const availability = await db
          .select()
          .from(therapistAvailability)
          .where(
            and(
              eq(therapistAvailability.therapistId, input.therapistId),
              eq(therapistAvailability.dayOfWeek, dayOfWeek)
            )
          );

        if (availability.length === 0) {
          return { slots: [] };
        }

        const avail = availability[0];
        const startTime = avail.startTime; // HH:mm
        const endTime = avail.endTime;

        // Get booked sessions for this date
        const bookedSessions = await db
          .select()
          .from(therapySessions)
          .where(
            and(
              eq(therapySessions.therapistId, input.therapistId),
              gte(therapySessions.scheduledAt, new Date(input.date)),
              gte(
                therapySessions.scheduledAt,
                new Date(input.date + 'T23:59:59')
              )
            )
          );

        // Generate available slots (30-minute intervals)
        const slots = generateTimeSlots(startTime, endTime, bookedSessions);

        return { slots };
      } catch (error) {
        console.error('[Scheduling] Error fetching available slots:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to fetch available slots',
        });
      }
    }),

  /**
   * Schedule a therapy session
   */
  scheduleSession: protectedProcedure
    .input(z.object({
      therapistId: z.number(),
      scheduledAt: z.string(), // ISO datetime string
      duration: z.number().default(60), // in minutes
    }))
    .mutation(async ({ input, ctx }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        const sessionDate = new Date(input.scheduledAt);

        // Check if slot is still available
        const conflictingSessions = await db
          .select()
          .from(therapySessions)
          .where(
            and(
              eq(therapySessions.therapistId, input.therapistId),
              eq(therapySessions.scheduledAt, sessionDate)
            )
          );

        if (conflictingSessions.length > 0) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'This time slot is no longer available',
          });
        }

        await db.insert(therapySessions).values({
          userId: ctx.user.id,
          therapistId: input.therapistId,
          scheduledAt: sessionDate,
          duration: input.duration,
          status: 'scheduled',
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        return { success: true };
      } catch (error) {
        console.error('[Scheduling] Error scheduling session:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to schedule session',
        });
      }
    }),

  /**
   * Get user's scheduled sessions
   */
  getUserSessions: protectedProcedure
    .input(z.object({
      status: z.enum(['scheduled', 'completed', 'cancelled', 'no-show']).optional(),
    }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        let query = db
          .select()
          .from(therapySessions)
          .where(eq(therapySessions.userId, ctx.user.id)) as any;

        if (input.status) {
          query = query.where(eq(therapySessions.status, input.status));
        }

        const sessions = await query.orderBy(
          desc(therapySessions.scheduledAt)
        );

        return sessions;
      } catch (error) {
        console.error('[Scheduling] Error fetching user sessions:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to fetch sessions',
        });
      }
    }),

  /**
   * Cancel a scheduled session
   */
  cancelSession: protectedProcedure
    .input(z.object({
      sessionId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        const session = await db
          .select()
          .from(therapySessions)
          .where(eq(therapySessions.id, input.sessionId))
          .limit(1);

        if (session.length === 0) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Session not found',
          });
        }

        if (session[0].userId !== ctx.user.id) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'You can only cancel your own sessions',
          });
        }

        await db
          .update(therapySessions)
          .set({ status: 'cancelled' })
          .where(eq(therapySessions.id, input.sessionId));

        return { success: true };
      } catch (error) {
        console.error('[Scheduling] Error cancelling session:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to cancel session',
        });
      }
    }),
});

/**
 * Generate available time slots (30-minute intervals)
 */
function generateTimeSlots(
  startTime: string,
  endTime: string,
  bookedSessions: any[]
): string[] {
  const slots: string[] = [];
  const [startHour, startMin] = startTime.split(':').map(Number);
  const [endHour, endMin] = endTime.split(':').map(Number);

  let currentHour = startHour;
  let currentMin = startMin;

  const bookedTimes = bookedSessions.map((s) =>
    s.scheduledAt.toISOString().substring(11, 16)
  );

  while (
    currentHour < endHour ||
    (currentHour === endHour && currentMin < endMin)
  ) {
    const timeStr = `${String(currentHour).padStart(2, '0')}:${String(
      currentMin
    ).padStart(2, '0')}`;

    if (!bookedTimes.includes(timeStr)) {
      slots.push(timeStr);
    }

    currentMin += 30;
    if (currentMin >= 60) {
      currentMin = 0;
      currentHour += 1;
    }
  }

  return slots;
}
