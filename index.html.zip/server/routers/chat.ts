import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { chatMessages, therapySessions, users } from '../../drizzle/schema';
import { eq, desc, and, gte, lte } from 'drizzle-orm';
import { TRPCError } from '@trpc/server';

export const chatRouter = router({
  /**
   * Get chat history with a therapist
   */
  getMessages: protectedProcedure
    .input(z.object({
      therapistId: z.number(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        // Get messages between user and therapist
        const messages = await db
          .select()
          .from(chatMessages)
          .where(
            and(
              or(
                and(
                  eq(chatMessages.senderId, ctx.user.id),
                  eq(chatMessages.recipientId, input.therapistId)
                ),
                and(
                  eq(chatMessages.senderId, input.therapistId),
                  eq(chatMessages.recipientId, ctx.user.id)
                )
              )
            )
          )
          .orderBy(desc(chatMessages.createdAt))
          .limit(input.limit)
          .offset(input.offset);

        // Mark messages as read
        await db
          .update(chatMessages)
          .set({ isRead: true })
          .where(
            and(
              eq(chatMessages.recipientId, ctx.user.id),
              eq(chatMessages.senderId, input.therapistId)
            )
          );

        return messages.reverse();
      } catch (error) {
        console.error('[Chat] Error fetching messages:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to fetch messages',
        });
      }
    }),

  /**
   * Send a message to therapist
   */
  sendMessage: protectedProcedure
    .input(z.object({
      recipientId: z.number(),
      message: z.string().min(1).max(5000),
    }))
    .mutation(async ({ input, ctx }) => {
      // Check if user has active subscription
      if (ctx.user.subscriptionStatus !== 'active') {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'This feature requires an active subscription',
        });
      }

      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        await db.insert(chatMessages).values({
          senderId: ctx.user.id,
          recipientId: input.recipientId,
          message: input.message,
          isRead: false,
          createdAt: new Date(),
        });

        return { success: true };
      } catch (error) {
        console.error('[Chat] Error sending message:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to send message',
        });
      }
    }),

  /**
   * Get list of therapists for user
   */
  getTherapists: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) {
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Database connection failed',
      });
    }

    try {
      const therapists = await db
        .select()
        .from(users)
        .where(eq(users.role, 'therapist'));

      return therapists;
    } catch (error) {
      console.error('[Chat] Error fetching therapists:', error);
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Failed to fetch therapists',
      });
    }
  }),

  /**
   * Get unread message count
   */
  getUnreadCount: protectedProcedure
    .input(z.object({
      therapistId: z.number().optional(),
    }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database connection failed',
        });
      }

      try {
        let query = db
          .select()
          .from(chatMessages)
          .where(
            and(
              eq(chatMessages.recipientId, ctx.user.id),
              eq(chatMessages.isRead, false)
            )
          ) as any;

        if (input.therapistId) {
          query = query.where(eq(chatMessages.senderId, input.therapistId));
        }

        const messages = await query;
        return { count: messages.length };
      } catch (error) {
        console.error('[Chat] Error fetching unread count:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to fetch unread count',
        });
      }
    }),
});

// Helper function for OR condition
function or(...conditions: any[]) {
  return conditions.reduce((acc, cond) => acc || cond);
}
