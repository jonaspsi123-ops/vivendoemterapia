import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Brain, Calendar, Zap, TrendingUp, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";


export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  // Fetch user data
  const { data: subscription, isLoading: subLoading } = trpc.subscription.getStatus.useQuery();
  const { data: tip, isLoading: tipsLoading } = trpc.wellness.getTodaysTip.useQuery();
  const { data: exercises, isLoading: exercisesLoading } = trpc.wellness.getExercises.useQuery({ type: 'breathing' });
  const { data: sessions, isLoading: sessionsLoading } = trpc.scheduling.getUserSessions.useQuery({ status: 'scheduled' });

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 md:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold" style={{ color: '#1A1A15' }}>
                Bem-vindo, {user?.name || 'Usuário'}!
              </h1>
              <p className="text-neutral-600 mt-1">Sua jornada de bem-estar emocional</p>
            </div>
            <div className="text-right">
              {subscription && (
                <div className="badge-therapy-primary px-4 py-2" style={{ backgroundColor: '#E8F0FF', color: '#4A90E2' }}>
                  {subscription.status === 'active' ? '✓ Assinatura Ativa' : 'Assinatura Inativa'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 md:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {/* Dicas Recebidas */}
          <div className="therapy-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-semibold">Dicas Recebidas</p>
                <p className="text-3xl font-bold mt-2" style={{ color: '#4A90E2' }}>
                  {tipsLoading ? <Skeleton className="w-12 h-8" /> : tip ? 1 : 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8F0FF' }}>
                <Heart className="w-6 h-6" style={{ color: '#4A90E2' }} />
              </div>
            </div>
          </div>

          {/* Exercícios Completos */}
          <div className="therapy-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-semibold">Exercícios</p>
                <p className="text-3xl font-bold mt-2" style={{ color: '#5CB85C' }}>
                  {exercisesLoading ? <Skeleton className="w-12 h-8" /> : Array.isArray(exercises) ? exercises.length : 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8F5E9' }}>
                <Zap className="w-6 h-6" style={{ color: '#5CB85C' }} />
              </div>
            </div>
          </div>

          {/* Próximas Sessões */}
          <div className="therapy-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-semibold">Próximas Sessões</p>
                <p className="text-3xl font-bold mt-2" style={{ color: '#9B7EBD' }}>
                  {sessionsLoading ? <Skeleton className="w-12 h-8" /> : Array.isArray(sessions) ? sessions.length : 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#F3E5F5' }}>
                <Calendar className="w-6 h-6" style={{ color: '#9B7EBD' }} />
              </div>
            </div>
          </div>

          {/* Progresso */}
          <div className="therapy-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm font-semibold">Progresso</p>
                <p className="text-3xl font-bold mt-2" style={{ color: '#F0AD4E' }}>
                  {subscription?.status === 'active' ? '100%' : '0%'}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#FFF3E0' }}>
                <TrendingUp className="w-6 h-6" style={{ color: '#F0AD4E' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="tips" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="tips">Dicas Diárias</TabsTrigger>
            <TabsTrigger value="exercises">Exercícios</TabsTrigger>
            <TabsTrigger value="sessions">Sessões</TabsTrigger>
            <TabsTrigger value="account">Conta</TabsTrigger>
          </TabsList>

          {/* Dicas Diárias */}
          <TabsContent value="tips" className="mt-6">
            <div className="space-y-4">
              {tipsLoading ? (
                <>
                  <Skeleton className="w-full h-24" />
                  <Skeleton className="w-full h-24" />
                </>
              ) : tip ? (
                  <div key={tip?.id} className="therapy-card">
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: '#E8F0FF' }}>
                        <Brain className="w-6 h-6" style={{ color: '#4A90E2' }} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold" style={{ color: '#1A1A15' }}>
                          {tip?.title}
                        </h3>
                        <p className="text-neutral-600 text-sm mt-1">{tip?.content}</p>
                        <p className="text-xs text-neutral-500 mt-2">
                          {tip?.createdAt ? new Date(tip.createdAt).toLocaleDateString('pt-BR') : ''}
                        </p>
                      </div>
                    </div>
                  </div>
              ) : (
                <div className="therapy-card text-center py-8">
                  <p className="text-neutral-600">Nenhuma dica disponível ainda</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Exercícios */}
          <TabsContent value="exercises" className="mt-6">
            <div className="space-y-4">
              {exercisesLoading ? (
                <>
                  <Skeleton className="w-full h-24" />
                  <Skeleton className="w-full h-24" />
                </>
              ) : exercises && exercises.length > 0 ? (
                exercises.map((exercise: any) => (
                  <div key={exercise.id} className="therapy-card">
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: '#E8F5E9' }}>
                        <Zap className="w-6 h-6" style={{ color: '#5CB85C' }} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold" style={{ color: '#1A1A15' }}>
                          {exercise.name}
                        </h3>
                        <p className="text-neutral-600 text-sm mt-1">{exercise.description}</p>
                        <p className="text-xs text-neutral-500 mt-2">
                          Duração: {exercise.duration} minutos
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="therapy-card text-center py-8">
                  <p className="text-neutral-600">Nenhum exercício disponível</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Próximas Sessões */}
          <TabsContent value="sessions" className="mt-6">
            <div className="space-y-4">
              {sessionsLoading ? (
                <>
                  <Skeleton className="w-full h-24" />
                  <Skeleton className="w-full h-24" />
                </>
              ) : sessions && sessions.length > 0 ? (
                sessions.map((session: any) => (
                  <div key={session.id} className="therapy-card">
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg flex-shrink-0 flex items-center justify-center" style={{ backgroundColor: '#F3E5F5' }}>
                        <Calendar className="w-6 h-6" style={{ color: '#9B7EBD' }} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold" style={{ color: '#1A1A15' }}>
                          Sessão de Terapia
                        </h3>
                        <p className="text-neutral-600 text-sm mt-1">
                          <Clock className="w-4 h-4 inline mr-1" />
                          {new Date(session.scheduledAt).toLocaleDateString('pt-BR')} às{' '}
                          {new Date(session.scheduledAt).toLocaleTimeString('pt-BR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                        <p className="text-xs text-neutral-500 mt-2">
                          Status: {session.status === 'confirmed' ? '✓ Confirmada' : 'Pendente'}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="therapy-card text-center py-8">
                  <p className="text-neutral-600">Nenhuma sessão agendada</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Conta */}
          <TabsContent value="account" className="mt-6">
            <div className="therapy-card max-w-2xl">
              <h3 className="text-xl font-bold mb-6" style={{ color: '#1A1A15' }}>
                Informações da Conta
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold text-neutral-700">Nome</label>
                  <p className="text-neutral-900 mt-1">{user?.name || 'Não informado'}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-neutral-700">Email</label>
                  <p className="text-neutral-900 mt-1">{user?.email || 'Não informado'}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-neutral-700">Assinatura</label>
                  <p className="text-neutral-900 mt-1">
                    {subscription?.status === 'active' ? (
                      <span style={{ color: '#5CB85C' }}>✓ Ativa</span>
                    ) : (
                      <span style={{ color: '#D9534F' }}>✗ Inativa</span>
                    )}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-neutral-700">Membro desde</label>
                  <p className="text-neutral-900 mt-1">
                    {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('pt-BR') : 'Não informado'}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
