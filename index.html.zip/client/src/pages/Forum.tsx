import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { MessageCircle, Eye, Plus, Search } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Forum() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewTopic, setShowNewTopic] = useState(false);
  const [newTopicData, setNewTopicData] = useState({ title: "", content: "" });

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = trpc.forum.getCategories.useQuery();

  // Fetch topics
  const { data: topics, isLoading: topicsLoading, refetch: refetchTopics } = trpc.forum.getTopics.useQuery({
    categoryId: selectedCategory,
    search: searchQuery || undefined,
    limit: 20,
    offset: 0,
  });

  // Create topic mutation
  const createTopicMutation = trpc.forum.createTopic.useMutation({
    onSuccess: () => {
      setShowNewTopic(false);
      setNewTopicData({ title: "", content: "" });
      refetchTopics();
    },
  });

  const handleCreateTopic = async () => {
    if (!selectedCategory || !newTopicData.title || !newTopicData.content) {
      alert("Preencha todos os campos");
      return;
    }

    await createTopicMutation.mutateAsync({
      categoryId: selectedCategory,
      title: newTopicData.title,
      content: newTopicData.content,
    });
  };

  const handleTopicClick = (topicId: number) => {
    setLocation(`/forum/topic/${topicId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950">
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 cosmic-glow">
            Comunidade de Apoio
          </h1>
          <p className="text-lg text-gray-300">
            Compartilhe suas experiências anonimamente e apoie outros membros da comunidade
          </p>
        </div>

        {/* Search and Create Button */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar tópicos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800/50 border-cyan-400/30 text-white placeholder-gray-400"
            />
          </div>
          <Button
            onClick={() => setShowNewTopic(true)}
            className="cosmic-button flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Novo Tópico
          </Button>
        </div>

        {/* New Topic Form */}
        {showNewTopic && (
          <Card className="cosmic-card mb-8">
            <h2 className="text-2xl font-bold text-white mb-6">Criar Novo Tópico</h2>
            
            {/* Category Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-3">
                Categoria
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedCategory === cat.id
                        ? "border-cyan-400 bg-cyan-400/20"
                        : "border-cyan-400/30 bg-slate-800/30 hover:border-cyan-400/50"
                    }`}
                  >
                    <span className="text-white font-medium">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Title */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Título
              </label>
              <Input
                placeholder="Título do seu tópico..."
                value={newTopicData.title}
                onChange={(e) => setNewTopicData({ ...newTopicData, title: e.target.value })}
                className="bg-slate-800/50 border-cyan-400/30 text-white placeholder-gray-400"
              />
            </div>

            {/* Content */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Conteúdo
              </label>
              <textarea
                placeholder="Descreva sua experiência ou pergunta..."
                value={newTopicData.content}
                onChange={(e) => setNewTopicData({ ...newTopicData, content: e.target.value })}
                rows={6}
                className="w-full bg-slate-800/50 border border-cyan-400/30 rounded-lg text-white placeholder-gray-400 p-3 focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
              <Button
                onClick={handleCreateTopic}
                disabled={createTopicMutation.isPending}
                className="cosmic-button"
              >
                {createTopicMutation.isPending ? "Criando..." : "Criar Tópico"}
              </Button>
              <Button
                onClick={() => setShowNewTopic(false)}
                variant="outline"
                className="border-cyan-400 text-cyan-400"
              >
                Cancelar
              </Button>
            </div>
          </Card>
        )}

        {/* Categories Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setSelectedCategory(undefined)}
            className={`px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
              selectedCategory === undefined
                ? "bg-cyan-400 text-slate-950"
                : "bg-slate-800/50 text-gray-300 hover:bg-slate-700/50"
            }`}
          >
            Todos
          </button>
          {categories?.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? "bg-cyan-400 text-slate-950"
                  : "bg-slate-800/50 text-gray-300 hover:bg-slate-700/50"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Topics List */}
        <div className="space-y-4">
          {topicsLoading ? (
            <div className="text-center py-12">
              <p className="text-gray-400">Carregando tópicos...</p>
            </div>
          ) : topics && topics.length > 0 ? (
            topics.map((topic: any) => (
              <Card
                key={topic.id}
                onClick={() => handleTopicClick(topic.id)}
                className="cosmic-card cursor-pointer hover:shadow-lg hover:shadow-cyan-500/50 transition-all group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    {topic.isPinned && (
                      <div className="inline-block bg-cyan-400/20 border border-cyan-400 rounded px-2 py-1 text-xs text-cyan-400 font-semibold mb-2">
                        📌 Fixado
                      </div>
                    )}
                    <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {topic.title}
                    </h3>
                    <p className="text-gray-400 mt-2 line-clamp-2">
                      {topic.content.substring(0, 150)}...
                    </p>
                    <div className="flex items-center gap-4 mt-4 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {topic.viewCount} visualizações
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-4 h-4" />
                        {topic.replyCount} respostas
                      </span>
                      <span className="text-xs">
                        Anônimo #{topic.anonymousNumber}
                      </span>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <p className="text-xs text-gray-500">
                      {new Date(topic.createdAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">
                Nenhum tópico encontrado. Seja o primeiro a criar um!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
