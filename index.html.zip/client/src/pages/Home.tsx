import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { ArrowRight, Heart, Brain, MessageCircle, Calendar, Zap, Shield, Users } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    window.location.href = getLoginUrl();
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 md:px-8 py-4 flex items-center justify-between">
          <div className="flex flex-col">
            <div className="text-2xl md:text-3xl font-bold" style={{ color: '#4A90E2' }}>
              Vivendo Em Terapia
            </div>
            <div className="text-xs md:text-sm text-neutral-600 mt-1">
              Com Jonas Gama de Castro
            </div>
          </div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <Button asChild className="btn-therapy-primary">
                <a href="/dashboard">Dashboard</a>
              </Button>
            ) : (
              <>
                <Button variant="ghost" style={{ color: '#4A90E2' }}>
                  <a href="#features">Recursos</a>
                </Button>
                <Button className="btn-therapy-primary" onClick={handleGetStarted}>
                  Entrar
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-white py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight" style={{ color: '#1A1A15' }}>
                Sua Jornada de <span className="gradient-text-therapy">Bem-Estar Emocional</span>
              </h1>
              <p className="text-xl text-neutral-600 mb-8 leading-relaxed">
                Conecte-se com Jonas Gama de Castro, psicanalista e terapeuta profissional. Receba dicas diárias personalizadas geradas por IA e transforme sua saúde mental através de exercícios terapêuticos interativos.
              </p>
              <div className="flex gap-4">
                <Button className="btn-therapy-primary" onClick={handleGetStarted}>
                  Começar Agora <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button className="btn-therapy-outline">
                  Saiba Mais
                </Button>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative w-full h-96 bg-gradient-to-br from-primary-light to-secondary-light rounded-2xl flex items-center justify-center">
                <div className="text-center">
                  <Heart className="w-24 h-24 mx-auto mb-4" style={{ color: '#4A90E2' }} />
                  <p className="text-lg font-semibold" style={{ color: '#2E5C8A' }}>Cuidado Profissional</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 md:py-32 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ color: '#1A1A15' }}>
              Funcionalidades Principais
            </h2>
            <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
              Tudo que você precisa para sua jornada de bem-estar emocional
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#E8F0FF' }}>
                <Brain className="w-6 h-6" style={{ color: '#4A90E2' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Dicas Diárias por IA
              </h3>
              <p className="text-neutral-600">
                Receba recomendações personalizadas de bem-estar emocional todos os dias, geradas por inteligência artificial.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#E8F5E9' }}>
                <Zap className="w-6 h-6" style={{ color: '#5CB85C' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Exercícios Terapêuticos
              </h3>
              <p className="text-neutral-600">
                Pratique respiração, mindfulness, meditação e journaling com guias interativos profissionais.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#F3E5F5' }}>
                <MessageCircle className="w-6 h-6" style={{ color: '#9B7EBD' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Chat com Terapeuta
              </h3>
              <p className="text-neutral-600">
                Converse com profissionais qualificados dentro da plataforma para suporte contínuo.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#E8F0FF' }}>
                <Calendar className="w-6 h-6" style={{ color: '#4A90E2' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Agendamento de Sessões
              </h3>
              <p className="text-neutral-600">
                Agende sessões de terapia com profissionais em horários que se adequam à sua rotina.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#E8F5E9' }}>
                <Users className="w-6 h-6" style={{ color: '#5CB85C' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Comunidade Anônima
              </h3>
              <p className="text-neutral-600">
                Compartilhe experiências e apoie outros usuários em um ambiente seguro e confidencial.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="therapy-card hover-lift">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: '#F3E5F5' }}>
                <Shield className="w-6 h-6" style={{ color: '#9B7EBD' }} />
              </div>
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1A1A15' }}>
                Privacidade Garantida
              </h3>
              <p className="text-neutral-600">
                Seus dados são protegidos com criptografia de ponta e conformidade com regulamentações.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ color: '#1A1A15' }}>
              Planos de Assinatura
            </h2>
            <p className="text-xl text-neutral-600 max-w-2xl mx-auto">
              Escolha o plano que melhor se adequa às suas necessidades
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {/* Monthly Plan */}
            <div className="therapy-card-elevated">
              <h3 className="text-2xl font-bold mb-2" style={{ color: '#1A1A15' }}>
                Mensal
              </h3>
              <p className="text-neutral-600 mb-6">Acesso completo por um mês</p>
              <div className="mb-6">
                <span className="text-4xl font-bold" style={{ color: '#4A90E2' }}>R$ 49</span>
                <span className="text-neutral-600">/mês</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Dicas diárias por IA</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Exercícios terapêuticos</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Chat com terapeuta</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Agendamento de sessões</span>
                </li>
              </ul>
              <Button className="btn-therapy-primary w-full" onClick={handleGetStarted}>
                Assinar Agora
              </Button>
            </div>

            {/* Annual Plan */}
            <div className="therapy-card-elevated relative" style={{ borderColor: '#4A90E2', borderWidth: '2px' }}>
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="badge-therapy-primary px-4 py-1" style={{ backgroundColor: '#E8F0FF', color: '#4A90E2' }}>
                  Mais Popular
                </span>
              </div>
              <h3 className="text-2xl font-bold mb-2" style={{ color: '#1A1A15' }}>
                Anual
              </h3>
              <p className="text-neutral-600 mb-6">Acesso completo por um ano</p>
              <div className="mb-6">
                <span className="text-4xl font-bold" style={{ color: '#4A90E2' }}>R$ 280</span>
                <span className="text-neutral-600">/ano</span>
                <p className="text-sm text-neutral-500 mt-2">Economize R$ 308 por ano</p>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Tudo do plano mensal</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Acesso prioritário</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Relatórios de progresso</span>
                </li>
                <li className="flex items-center gap-2">
                  <span style={{ color: '#5CB85C' }}>✓</span>
                  <span>Suporte prioritário</span>
                </li>
              </ul>
              <Button className="btn-therapy-primary w-full" onClick={handleGetStarted}>
                Assinar Agora
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Therapist Section */}
      <section className="py-20 md:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-6 md:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ color: '#1A1A15' }}>
              Sobre Jonas Gama de Castro
            </h2>
          </div>
          <div className="therapy-card">
            <p className="text-lg text-neutral-700 leading-relaxed mb-6">
              Jonas Gama de Castro é psicanalista, terapeuta e escritor com vasta experiência em saúde mental e bem-estar emocional. Dedicado a transformar vidas através da terapia acessível e humanizada, Jonas criou a plataforma "Vivendo Em Terapia" para levar cuidado profissional a todos.
            </p>
            <p className="text-lg text-neutral-700 leading-relaxed mb-6">
              Com formação sólida em psicanálise e terapia emocional, Jonas combina técnicas comprovadas com tecnologia inovadora para oferecer uma experiência única de bem-estar mental.
            </p>
            <p className="text-lg text-neutral-700 leading-relaxed">
              Localizado em Campos dos Goytacazes, RJ, Jonas está comprometido em divulgar seus serviços profissionais e ajudar as pessoas a viverem melhor.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32" style={{ backgroundColor: '#E8F0FF' }}>
        <div className="max-w-4xl mx-auto px-6 md:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ color: '#1A1A15' }}>
            Comece Sua Jornada Hoje
          </h2>
          <p className="text-xl text-neutral-600 mb-8">
            Junte-se a milhares de pessoas que já transformaram sua saúde mental e emocional com Jonas Gama de Castro
          </p>
          <Button className="btn-therapy-primary btn-lg" onClick={handleGetStarted}>
            Criar Conta Grátis <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Vivendo Em Terapia</h4>
              <p className="text-neutral-400">Transformando vidas através da terapia digital acessível.</p>
              <p className="text-neutral-400 text-sm mt-2">Com Jonas Gama de Castro</p>
              <p className="text-neutral-400 text-sm">Campos dos Goytacazes, RJ</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Produto</h4>
              <ul className="space-y-2 text-neutral-400">
                <li><a href="#" className="hover:text-white">Recursos</a></li>
                <li><a href="#" className="hover:text-white">Preços</a></li>
                <li><a href="#" className="hover:text-white">Segurança</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Empresa</h4>
              <ul className="space-y-2 text-neutral-400">
                <li><a href="#" className="hover:text-white">Sobre Jonas</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Contato</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-neutral-400">
                <li><a href="#" className="hover:text-white">Privacidade</a></li>
                <li><a href="#" className="hover:text-white">Termos</a></li>
                <li><a href="#" className="hover:text-white">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-neutral-800 pt-8 text-center text-neutral-400">
            <p>&copy; 2026 Vivendo Em Terapia. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
