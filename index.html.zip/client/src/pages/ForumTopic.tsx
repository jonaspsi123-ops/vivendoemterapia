import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Heart, MessageCircle, ThumbsUp } from "lucide-react";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";

export default function ForumTopic() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/forum/topic/:id");
  const topicId = params?.id ? parseInt(params.id) : 0;
  const [replyContent, setReplyContent] = useState("");

  // Fetch topic and replies
  const { data: topicData, isLoading, refetch } = trpc.forum.getTopic.useQuery(
    { id: topicId },
    { enabled: topicId > 0 }
  );

  // Create reply mutation
  const createReplyMutation = trpc.forum.createReply.useMutation({
    onSuccess: () => {
      setReplyContent("");
      refetch();
    },
  });

  // Mark reply helpful mutation
  const markHelpfulMutation = trpc.forum.markReplyHelpful.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  const handleCreateReply = async () => {
    if (!replyContent.trim()) {
      alert("Digite uma resposta");
      return;
    }

    await createReplyMutation.mutateAsync({
      topicId,
      content: replyContent,
    });
  };

  const handleMarkHelpful = async (replyId: number, isHelpful: boolean) => {
    await markHelpfulMutation.mutateAsync({
      replyId,
      isHelpful,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
        <p className="text-gray-400 text-lg">Carregando tópico...</p>
      </div>
    );
  }

  if (!topicData?.topic) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950 flex items-center justify-center">
        <p className="text-gray-400 text-lg">Tópico não encontrado</p>
      </div>
    );
  }

  const { topic, replies } = topicData;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950">
      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Back Button */}
        <button
          onClick={() => setLocation("/forum")}
          className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Fórum
        </button>

        {/* Topic */}
        <Card className="cosmic-card mb-8">
          <div className="mb-6">
            <h1 className="text-3xl md:text-4xl font-bold text-white cosmic-glow mb-4">
              {topic.title}
            </h1>
            <div className="flex items-center gap-4 text-sm text-gray-400 mb-6">
              <span>Anônimo #{topic.anonymousNumber}</span>
              <span>•</span>
              <span>{new Date(topic.createdAt).toLocaleDateString("pt-BR")}</span>
              <span>•</span>
              <span>{topic.viewCount} visualizações</span>
            </div>
          </div>

          <div className="prose prose-invert max-w-none">
            <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
              {topic.content}
            </p>
          </div>
        </Card>

        {/* Replies Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">
            Respostas ({replies?.length || 0})
          </h2>

          {/* Reply Form */}
          <Card className="cosmic-card mb-8">
            <h3 className="text-lg font-bold text-white mb-4">Sua Resposta</h3>
            <textarea
              placeholder="Compartilhe sua experiência ou apoio..."
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              rows={5}
              className="w-full bg-slate-800/50 border border-cyan-400/30 rounded-lg text-white placeholder-gray-400 p-3 focus:outline-none focus:border-cyan-400 mb-4"
            />
            <Button
              onClick={handleCreateReply}
              disabled={createReplyMutation.isPending}
              className="cosmic-button"
            >
              {createReplyMutation.isPending ? "Enviando..." : "Enviar Resposta"}
            </Button>
          </Card>

          {/* Replies List */}
          <div className="space-y-4">
            {replies && replies.length > 0 ? (
              replies.map((reply: any) => (
                <Card key={reply.id} className="cosmic-card">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-400">
                        Anônimo #{reply.anonymousNumber}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(reply.createdAt).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-cyan-400 font-semibold">
                        {reply.helpfulCount} pessoas acharam útil
                      </p>
                    </div>
                  </div>

                  <p className="text-gray-300 leading-relaxed whitespace-pre-wrap mb-4">
                    {reply.content}
                  </p>

                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => handleMarkHelpful(reply.id, true)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/50 hover:bg-cyan-400/20 border border-cyan-400/30 hover:border-cyan-400 text-cyan-400 transition-all text-sm"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      Útil
                    </button>
                    <button
                      onClick={() => handleMarkHelpful(reply.id, false)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 border border-gray-600/30 hover:border-gray-600 text-gray-400 transition-all text-sm"
                    >
                      <Heart className="w-4 h-4" />
                      Apoiar
                    </button>
                  </div>
                </Card>
              ))
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400">
                  Nenhuma resposta ainda. Seja o primeiro a responder!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
